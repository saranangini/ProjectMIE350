package com.mie.model;

public class Admin extends Member{

	public Admin(){
		this.admin=true;
	}
}